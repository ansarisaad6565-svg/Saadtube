package com.saad.saadtube

import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : ComponentActivity() {
    private lateinit var wv: WebView
    private lateinit var root: FrameLayout
    private var cv: View? = null
    private var cb: WebChromeClient.CustomViewCallback? = null

    inner class Bridge {
        private val sp = getSharedPreferences("st", Context.MODE_PRIVATE)
        @JavascriptInterface fun get(k: String): String = sp.getString(k, "") ?: ""
        @JavascriptInterface fun set(k: String, v: String) { sp.edit().putString(k, v).apply() }
        @JavascriptInterface fun share(t: String) {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t), "Share"))
        }
        @JavascriptInterface fun open(u: String) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
    }

    private fun fs(on: Boolean) {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        if (on) {
            c.hide(WindowInsetsCompat.Type.systemBars())
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    private fun hideCustom() {
        cv?.let { root.removeView(it) }; cv = null
        cb?.onCustomViewHidden(); cb = null
        wv.visibility = View.VISIBLE; fs(false)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.parseColor("#0f0f0f")
        window.navigationBarColor = Color.parseColor("#0f0f0f")
        root = FrameLayout(this); root.setBackgroundColor(Color.BLACK)
        wv = WebView(this); root.addView(wv, ViewGroup.LayoutParams(-1, -1))
        setContentView(root)
        wv.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; mediaPlaybackRequiresUserGesture = false }
        wv.addJavascriptInterface(Bridge(), "Android")
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (r.isForMainFrame) { startActivity(Intent(Intent.ACTION_VIEW, r.url)); return true }
                return false
            }
        }
        wv.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(v: View, c: CustomViewCallback) {
                cv = v; cb = c
                root.addView(v, ViewGroup.LayoutParams(-1, -1)); wv.visibility = View.GONE; fs(true)
            }
            override fun onHideCustomView() { hideCustom() }
        }
        val html = assets.open("index.html").bufferedReader().readText()
        // App-id style https base URL: YouTube's player expects a referrer that identifies the app
        wv.loadDataWithBaseURL("https://com.saad.saadtube/", html, "text/html", "utf-8", null)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (cv != null) { hideCustom(); return }
                wv.evaluateJavascript("window.goBack&&window.goBack()") { if (it != "true") finish() }
            }
        })
    }

    override fun onDestroy() { wv.destroy(); super.onDestroy() }
}
