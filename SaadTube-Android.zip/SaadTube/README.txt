SAADTUBE (native Android, no sign-in) - by Saad
1. Android Studio (free) install karo. Is folder ko Open karo, Gradle sync hone do (pehli baar internet chahiye).
2. Build > Build Bundle(s)/APK(s) > Build APK(s) > locate -> app-debug.apk phone me install karo.
3. App kholo, free YouTube Data API v3 key daalo (console.cloud.google.com > Enable "YouTube Data API v3" > Credentials > API key). Key ko restrict mat karo ya sirf YouTube Data API tak rakho.
4. Subscriptions/likes/playlists/history sirf phone me save hote hain. Free quota 10,000 units/din (1 search = 100 units).
Video "Error 153" aaye to Android System WebView / Chrome update karo.
